#!/bin/bash

tar -cvf shell_scripts.tar *.sh
gzip shell_scripts.tar
