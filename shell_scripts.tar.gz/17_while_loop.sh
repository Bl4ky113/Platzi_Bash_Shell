#!/bin/bash

num=0

while [ $num -lt 20 ]
do
    echo "num: $num"
    num=$(( num + 1 ))
done
