#!/bin/bash

current_dir=`pwd`
fruits=$(echo "bananas")

echo "dir: $current_dir"
echo "Bananas: $fruits"
