#!/bin/bash

echo "Variable exportada: $nombre"
