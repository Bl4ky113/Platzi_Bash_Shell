#!/bin/bash

echo "$REPLY"
echo "Hello, How Are You Today?  "
read
echo "$REPLY"
echo "How's the weather today?  "
read
echo "$REPLY"
