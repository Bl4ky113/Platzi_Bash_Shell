#!/bin/bash

personal_reply=""
weather_reply=""

read -p "Hi, how are you today? " personal_reply
read -p "How's the weather today? " weather_reply

echo "$personal_reply, $weather_reply"

