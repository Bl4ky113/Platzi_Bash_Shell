#!/bin/bash

read -s -n 10 -p "Enter your Password (max 10 chars): " password
echo -e "\nNever give someone your password, especially me, $password"
