#!/bin/bash

echo "Argument 1: $1"
echo "Arhument 2: $2"
echo "File Name: $0"
echo -e "Number of Arguments $#\n Arguments: $*"
