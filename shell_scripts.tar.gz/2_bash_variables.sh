#!/bin/bash

variable_1="hello"
varaible_2=hello
nombre=Bl4ky

export nombre

echo "Comillas $variable_1, sin comillas $variable_2"

./2_recive_exported_variables.sh
