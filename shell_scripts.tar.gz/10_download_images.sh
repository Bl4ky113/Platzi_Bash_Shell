#!/bin/bash

wget https://www.publicdomainpictures.net/pictures/40000/velka/rough-collie-dog-1365447402YrJ.jpg \
    -O cute_dog.jpg

viewnior ./cute_dog.jpg
