#!/bin/bash

# Hello World in Bash

echo "Hello World"
